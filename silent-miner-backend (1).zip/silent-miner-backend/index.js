const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

const BOT_TOKEN = process.env.BOT_TOKEN;
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET;
const TELEGRAM_API = `https://api.telegram.org/bot${BOT_TOKEN}`;

const users = {};
const mined = {};

app.post(`/webhook/${WEBHOOK_SECRET}`, async (req, res) => {
  const msg = req.body.message;
  const chatId = msg.chat.id;
  const text = msg.text || '';

  if (!users[chatId]) users[chatId] = { mining: false, total: 0 };

  if (text === '/start') {
    await axios.post(`${TELEGRAM_API}/sendMessage`, {
      chat_id: chatId,
      text: `Welcome to Silent Miner (SINE)! Tap "Start Mining" to begin.`,
      reply_markup: {
        keyboard: [[{ text: "⛏ Start Mining" }]],
        resize_keyboard: true
      }
    });
  } else if (text.includes("Start Mining")) {
    users[chatId].mining = true;
    let amount = Math.random() < 0.05 ? 5 : 1; // lucky boost
    users[chatId].total += amount;
    mined[chatId] = (mined[chatId] || 0) + amount;
    await axios.post(`${TELEGRAM_API}/sendMessage`, {
      chat_id: chatId,
      text: `⛏ You mined ${amount} SINE! Total: ${users[chatId].total} SINE`
    });
  }

  res.sendStatus(200);
});

app.get("/", (req, res) => res.send("Silent Miner Backend is Live"));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));